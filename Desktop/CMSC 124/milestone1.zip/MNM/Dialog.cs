using System;

namespace Proto
{
	public partial class Dialog : Gtk.Dialog
	{
		public Dialog ()
		{
			this.Build ();
		}
	}
}

